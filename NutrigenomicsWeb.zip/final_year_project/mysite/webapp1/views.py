from django.shortcuts import render
from django.http import HttpResponse


def home(request):
    return render(request, 'personal/home.html',  )

def food(request):
    return render(request, 'personal/food.html')


